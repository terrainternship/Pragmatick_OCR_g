import meeting as mtg
import scan_preparation as prep
import utils as utl

meeting = mtg.Meeting('./bulletins/testPDF.pdf')
print(f'Номер собрания: "{meeting.number}"')
print(f'Имя базового PDF-файла: "{meeting.base_bulletin.file_name}"')
bulletin_number = meeting.base_bulletin.get_bulletin_number()
print(f'Бюллетень № {bulletin_number.text}, bbox:{bulletin_number.bbox}')
meeting_data = meeting.get_data()
for page_num, page_bbox, page_markers, page_question_lines,\
        footer in meeting_data:
    print(f'  Страница №{page_num +1}, bbox:{page_bbox}')
    for key, marker in page_markers.items():
        print(f'      Маркер №{key+1}: name:{marker.text}, bbox:{marker.bbox}')
    for key, question_line in page_question_lines.items():
        print(
            f'      Вопрос {key+1}: №{question_line.text}, '\
            f'bbox:{question_line.bbox}')
    print('    Нижний колонтитул:')
    print(f'        номер страницы: {footer.page_number.text}, '\
        f'bbox:{footer.page_number.bbox}')
    print(f'        бюллетень № {footer.bulletin_number.text}, '\
        f'bbox:{footer.bulletin_number.bbox}')

meeting.base_bulletin.draw_pages()
meeting.save_data()

page = meeting.base_bulletin.pages[0]
page_height = page.bbox.height
t=page.markers[2].bbox.centre.y
l=page.markers[0].bbox.centre.x
b=page.markers[1].bbox.centre.y
r=page.markers[1].bbox.centre.x
# Расстояние между маркерами в базовом PDF
height = abs(b-t)
width = r-l
# # координаты обрезки полос голосования
# l_down = meeting_data[0][4][0][1][0].cornerLD.x, meeting_data[0][4][0][1][0].cornerLD.y
# r_up = meeting_data[0][4][0][1][2].cornerRUp.x, meeting_data[0][4][0][1][2].cornerRUp.y
scan = prep.prepare('./bulletins/photo_2023-11-10_15-42-33_90cw.jpg', height=height, dl=5)
htable=35
wtable = 290
centre = page.question_lines[0].bbox.get_bbox_abs(d_x = l, d_y=t).centre
bbox = utl.BoundingBox(left=centre.x-145, top=centre.y-17, right=centre.x+145, bottom=centre.y+18)
utl.bboxes_draw('result', scan, norm_bboxes=[bbox], is_relative=False)
