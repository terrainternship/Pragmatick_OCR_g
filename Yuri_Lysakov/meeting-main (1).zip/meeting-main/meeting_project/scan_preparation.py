import utils as utl
import cv2
import cv2.typing as cvtp
import numpy as np
from imutils.perspective import four_point_transform

def preprocess_image(image: cvtp.MatLike,
                     blur: float = 1.1,
                     black_threshold: int = 120,
                     ratio: float = 1.0
                     )->cvtp.MatLike:
    """Предварительная обработка изображения.

    Args:
        image (cvtp.MatLike): Входное изображение
        blur (float, optional): Степень размытия - стандартное отклонение ядра.
            Defaults to 1.1.
        black_threshold (int, optional): порог чёрного цвета
            (меньше - черные, больше - белые). Defaults to 120.
        ratio (float, optional): коэффициент масштабирования. Defaults to 1.

    Returns:
        cvtp.MatLike: Обработанное изображение
    """
    
    # перевод изображения в оттенки серого
    bw_result = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # размываем
    bw_result = cv2.GaussianBlur( src=bw_result, ksize=(0,0), sigmaX=blur)
    utl.cv2_show('',bw_result)

    # перевод изображения в черно-белый вариант
    bw_result = cv2.threshold(bw_result, black_threshold, 255, cv2.THRESH_BINARY)[1]
    utl.cv2_show('',bw_result)

    # Масштабирвоание изображения
    # Масштабирование после преобразований дает лучший результат для поиска по маске
    bw_result = cv2.resize(bw_result, None, fx=ratio, fy=ratio)

    # Инвертируем изображение - обеспечивает лучщее обнаружение
    # квадрата с черным контуром и белой серединой
    bw_result = 255 - bw_result
    utl.cv2_show('Black-white', bw_result)

    return bw_result

def find_black_square(image: cvtp.MatLike,
                      kernel_size: int = 5,
                      iterations: int = 3
                      )->cvtp.MatLike:
    """Поиск маски из квадратов с помощью математической морфологии.

    Args:
        image (cvtp.MatLike): Входное двухцветное чёрно-белое изображение
        kernel_size (int, optional): Размер ядра для выполнения
            математического закрытия. Defaults to 5.
        iterations (int, optional): Количество итераций. Defaults to 3.

    Returns:
        cvtp.MatLike: Маска, где белые области - квадраты, черные - фон.
    """

    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (kernel_size, kernel_size))
    result = cv2.morphologyEx(image, cv2.MORPH_CLOSE, kernel, iterations=iterations)
    result = 255 - result
    utl.cv2_show('Mask', result)
    return result

def get_contours(mask_image: cvtp.MatLike,
                 color_img: cvtp.MatLike,
                 area_threshold_min = 50,
                 area_threshold_max = 120,
                 black_threshold = 120,
                 relative = True
                 ):# 50,120
    """
    Нахождение относительных координат объектов
    Поиск выполняется по маске, где белые области - квадраты, черные - фон.
    Возвращается numpy массив с координатами квадратов.
    :param image_mask: Входная маска.
    :param area_threshold: Порог для фильтрации слишком больших объектов.
    :param relative: Возвращать относительные или абсолютные координаты.
    """
    # Найти все контуры фигур  (Можно попробовать cv2.RETR_LIST)
    contours = cv2.findContours(mask_image, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    contours = contours[0] if len(contours) == 2 else contours[1]
    centers = []
    for c in contours:
        # Находим разницу между максимальным и минимальным значениями по каждой оси
        delta = np.abs( np.max(c, axis=0) - np.min(c, axis=0))
        # Разница между дельтами по х и по y (для квадрата = 0)
        ddelta = abs(delta[:,0]-delta[:,1])
        if (ddelta < 3 and delta > 4).all()\
            and (delta < 13).all()\
            and cv2.contourArea(c) > area_threshold_min\
            and cv2.contourArea(c) < area_threshold_max:#3,5,12
            center = np.mean([np.max(c, axis=0), np.min(c, axis=0)], axis=0)[0]
            color = color_img[int(center[1]), int(center[0])]
             # Находим разницу между максимальным и минимальным значениями по каждой оси
            c_delta = np.abs( np.max(color, axis=0) - np.min(color, axis=0))
            # Если разброс между каналами превышает заданный предел, есть цвет, значит это не лист 
            if c_delta<30:
                centers.append (center)

    if len(centers) > 3:
         # Если найдено больше 3-х центров, берем 1, 2, предпоследний и последний
        centers = np.array(centers)[[0,1,-2,-1]]
    else:
        return []

    # Сортируем точки
    result = []
    for i in range(len(centers)):
        print(centers[i])
    if centers[0][0,]<centers[1][0,]:
        result.append(centers[0])
        result.append(centers[1])
    else:
        result.append(centers[1])
        result.append(centers[0])
    if centers[2][0,]<centers[3][0,]:
        result.append(centers[3])
        result.append(centers[2])
    else:
        result.append(centers[2])
        result.append(centers[3])
    centers = np.array(result)
    # centers = np.array(centers)
    # print('centers', centers)

    is_rotate_180 = False
    # Если цвет в центре второго маркера ближе к белому, значит нужно поворачивать на 180
    if np.mean(color_img[int(centers[1][1]), int(centers[1][0])]) > black_threshold:
        is_rotate_180 = True

    if relative:
        centers[:, 0] = centers[:, 0] / mask_image.shape[1]
        centers[:, 1] = centers[:, 1] / mask_image.shape[0]

    return [centers, is_rotate_180]#, area

# Поскольку номер внизу обрезается, нужно добавить приращения вниз на l пикселей (для оригинала)
# Для этого нужно найти координаты нижних маркеров со смещением и с учетом искажения фото
def get_offset_point(x1, y1, x2, y2, dy=783.37, dl=5, is_rotate_180=False):
    '''
        Функция вычисления координаты точки со смещением
        x1, y1 - координаты нижнего угла
        x2, y2 - координаты верхего угла (с той же стороны листа)
        dy - расстояние между центрами верхнего и нижнего маркеров в образцовом PDF
        dl - приращение в пикселях для оригинального PDF (чтобы смещение вниз захватило номер бюллетеня)
        is_rotate_180 - требуется ли поворот листа на 180 град. (True - приращение будет рассчитано вверх, False - вниз)
    '''
    # Расстояние между точками
    h = ((x1-x2)**2 + (y1-y2)**2)**0.5
    # Приращение с учетом соотношения оригинального и текущего расстояния между маркерами
    dl = dl*h/dy
    # Коэффициент приращения
    k = dl/h
    # Находим координаты с учетом приращения и необходим ли поворот на 180
    if is_rotate_180:
        x = x2+(x2-x1)*k
        y = y2+(y2-y1)*k
    else:
        x = x1+(x1-x2)*k
        y = y1+(y1-y2)*k
    return [x,y]

#___________________________________________________________
def prepare(path_file: str, height: float, dl: int = 5):#, width: float
    # dl - приращение в пикселях для оригинального PDF (чтобы смещение от центра нижних маркеров вниз захватило номер бюллетеня)
    orig_img = cv2.imread(path_file)

    # Задаем параметры
    # размер масштабирования до размеров с минимальной стороной scale_to пикселей
    # масштабируем только для поиска реперов.
    scale_to = 800
    black_threshold = 120 # порог чёрного цвета (меньше - черные, больше - белые)
    blur = 1.1 # Определяет степень размытия

    

    if orig_img.shape[1]>orig_img.shape[0]:
        orig_img = cv2.rotate(orig_img, rotateCode=cv2.ROTATE_90_CLOCKWISE)
    print('Scan image shape:', orig_img.shape)

    # Нахождение коэффициента масштабирования
    ratio = scale_to/min(orig_img.shape[:2])
    bw_img = preprocess_image(orig_img, blur=blur, black_threshold=black_threshold, ratio=ratio)

    mask_img = find_black_square(image=bw_img, kernel_size=3, iterations=2) # Итерации можно увеличить до 3-х

    resize_img=cv2.resize(orig_img, None, fx=ratio, fy=ratio)
    coords, is_rotate_180 = get_contours(mask_image=mask_img, color_img=resize_img, black_threshold=120, relative=False)
    #print(len(coords))

    vis_image = utl.crosses_draw(resize_img, coords, size=9, thickness=2, color=(0, 255, 0), relative=False) # Рисуем найденный контур, -1 означает залить
    utl.cv2_show('', vis_image)

    # Пробное преобразование перспективы - (снизу обрезаются цифры номера) (В результирующей версии удалить)
    wraped_img = four_point_transform(orig_img, coords.astype(np.int32)/ratio)
    # Если нужно, поворачиваем изображение
    if (is_rotate_180):
        wraped_img=cv2.rotate(wraped_img, rotateCode=cv2.ROTATE_180)
    # Показываем результат
    utl.cv2_show('wrap',wraped_img)


    # Расчет приращения для устранения обрезки нижнего номера бюллетеня
    if (is_rotate_180):
        coords[3][0], coords[3][1] = get_offset_point(coords[0][0], coords[0][1], coords[3][0], coords[3][1], dy=height, is_rotate_180=is_rotate_180, dl=dl)
        coords[2][0], coords[2][1] = get_offset_point(coords[1][0], coords[1][1], coords[2][0], coords[2][1], dy=height, is_rotate_180=is_rotate_180, dl=dl)
    else:
        coords[0][0], coords[0][1] = get_offset_point(coords[0][0], coords[0][1], coords[3][0], coords[3][1], dy=height, is_rotate_180=is_rotate_180, dl=dl)
        coords[1][0], coords[1][1] = get_offset_point(coords[1][0], coords[1][1], coords[2][0], coords[2][1], dy=height, is_rotate_180=is_rotate_180, dl=dl)

    # Восстанавливаем геометрию до прямоугольника с обрезкой по центрам маркеров и с учетом приращения
    wraped_img = four_point_transform(orig_img, coords.astype(np.int32)/ratio)

    # Если нужно, поворачиваем изображение
    if (is_rotate_180):
        # orig_img=cv2.rotate(orig_img, rotateCode=cv2.ROTATE_180)
        wraped_img=cv2.rotate(wraped_img, rotateCode=cv2.ROTATE_180)

    # Показываем и сохраняем результат
    ratio = 703/min(wraped_img.shape[:2])
    wraped_img=cv2.resize(wraped_img, None, fx=ratio, fy=ratio)
    utl.cv2_show('wrap',wraped_img)
    # wraped = cv2.cvtColor(wraped, cv2.COLOR_BGR2GRAY)
    # utl.cv2_show('wrap2',wraped)
    # ref = cv2.threshold(wraped, 120, 255, cv2.THRESH_BINARY)[1]
    # utl.cv2_show('ref',ref)
    # utl.cv2_show('result.jpg', ref)
    return wraped_img
