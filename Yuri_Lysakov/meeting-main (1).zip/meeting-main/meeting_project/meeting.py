import pypdf
from pdfminer.high_level import extract_pages
from pdfminer.layout import LTTextContainer, LTFigure
from pdf2image import convert_from_path
import numpy as np
import cv2.typing as cvtp
import utils as utl
import json
import os

#____________________________________________________________________
class TextBox:
    """Класс строки для хранения текста с bbox
    """

    def __init__(self, text: str, bbox: utl.BoundingBox):
        self.text: str = text
        self.bbox: utl.BoundingBox = bbox

    def get_JSON(self):    
        return {
            'number': self.text,
            'bbox': self.bbox.get_JSON()
            }

#____________________________________________________________________
class Footer:
    """Нижний колонтитул
    """
    
    # Размер bbox № страницы в % общей ширины bbox для № страницы и № бюллетеня
    PAGE_NUM_WIDTH_PERCENT = 10.0
    def __init__(self,
                 page_number: str,
                 bulletin_number: str,
                 bbox: utl.BoundingBox):
        page_num_right = bbox.left + bbox.width*self.PAGE_NUM_WIDTH_PERCENT/100
        t_bbox = utl.BoundingBox(left=bbox.left,
                                        top=bbox.top,
                                        right=page_num_right,
                                        bottom=bbox.bottom)
        self.page_number: TextBox = TextBox(text=page_number, bbox=t_bbox)
        t_bbox = utl.BoundingBox(left=page_num_right,
                                        top=bbox.top,
                                        right=bbox.right,
                                        bottom=bbox.bottom)
        self.bulletin_number: TextBox = TextBox(text=bulletin_number, bbox=t_bbox)

    def get_JSON(self):
        return {
                'page_number': self.page_number.get_JSON(),
                'bulletin_number': self.bulletin_number.get_JSON()
                }

#____________________________________________________________________
class Page:
    'Страница'
    def __init__(self):
        self.bbox: utl.BoundingBox # utl.BoundingBox
         # Словарь id номеров строк голосования lineId:number
        self.__line_id_dict: dict[int, int] = {}
        self.question_lines: dict[int, TextBox] = {}
        self.footer: Footer
        self.markers: dict[int, TextBox] = {}
        self.image: cvtp.MatLike # пиксельное изображение страницы

    def set_question_line(self,
                          lineId: int,
                          question_num: str,
                          bbox: utl.BoundingBox):
        if lineId not in self.__line_id_dict:
            self.__line_id_dict[lineId] = len(self.__line_id_dict)
            self.question_lines[self.__line_id_dict[lineId]] = TextBox(
                text=question_num,
                bbox=bbox)

    def set_marker(self, marker_name: str, bbox: utl.BoundingBox):
        self.markers[len(self.markers)] = TextBox(text=marker_name, bbox=bbox)

    def get_JSON(self):
        json_text_m = {}
        for num, marker in self.markers.items():
            json_text_m[f'marker_{num+1}'] = marker.get_JSON()        
        json_text_q = {}
        for num, question_line in self.question_lines.items():
            json_text_q[f'line_{num+1}'] = question_line.get_JSON()
        return {
            'bbox': self.bbox.get_JSON(),
            'markers': json_text_m,
            'question_lines': json_text_q,
            'footer': self.footer.get_JSON()
            }


#____________________________________________________________________
class Bulletin:
    'Бюллетень голосования'
    
    def __init__(self):
        self.file_name: str
        self.bulletin_number: TextBox
        self.pages: list[Page] = []

    def set_bulletin_number(self, value: str, bbox: utl.BoundingBox):
        self.bulletin_number = TextBox(text=value, bbox=bbox)

    def set_page_bbox(self, page_num: int, bbox: utl.BoundingBox):
        self.pages[page_num].bbox=bbox

    def set_page_image(self, page_num: int, image: cvtp.MatLike):
        self.pages[page_num].image = image

    def set_page_question_line(self, page_num: int, lineId: int,
                        question_num:str, bbox: utl.BoundingBox):
        self.pages[page_num].set_question_line(
            lineId=lineId,
            question_num=question_num,
            bbox = bbox)

    def set_page_footer(self,
                        page_num: int,
                        page_number: str,
                        bulletin_number: str,
                        bbox: utl.BoundingBox):
        self.pages[page_num].footer = Footer(page_number=page_number,
                                        bulletin_number=bulletin_number,
                                        bbox = bbox)

    def get_bulletin_number(self):
        return self.bulletin_number

    def get_data(self)->[[int,
                          utl.BoundingBox,
                          [TextBox],
                          [TextBox],
                          Footer]]:
        result = []
        for page_num, page in enumerate(self.pages):
            result.append([page_num, page.bbox, page.markers,
                           page.question_lines, page.footer])
        return result

    def draw_pages(self):
        """Отрисовываем изображениях страниц c нужными bboxes
        """

        for page_num, page in enumerate(self.pages):
            image = page.image
            width = page.bbox.width
            height = page.bbox.height
            bboxes = list()
            if page_num==0:
                utl.cv2_show(title="Base image", image=image)
                bboxes.append(self.bulletin_number.bbox.get_bbox_norm(
                    div_x=width,
                    div_y=height))
            for marker in page.markers.values():
                bboxes.append(marker.bbox.get_bbox_norm(
                    div_x=width,
                    div_y=height))
            for question_line in page.question_lines.values():
                bboxes.append(
                    question_line.bbox.get_bbox_norm(
                        padding_x=0.85,
                        padding_y=33.8,
                        div_x=width,
                        div_y=height))
            bboxes.append(page.footer.page_number.bbox.get_bbox_norm(
                    div_x=width,
                    div_y=height))
            bboxes.append(page.footer.bulletin_number.bbox.get_bbox_norm(
                    div_x=width,
                    div_y=height))
            utl.bboxes_draw(title='Page ' + str(page_num+1),
                            image=image,
                            norm_bboxes=bboxes)

    def get_JSON(self):
        json_text = {}
        for num, page in enumerate(self.pages):
            json_text[f'page_{num+1}'] = page.get_JSON()
        return {
            'file_name': self.file_name,
            'bulletin_number': self.bulletin_number.get_JSON(),
            'pages': json_text
            }
#____________________________________________________________________
class Meeting:
    """Класс Голосования
    """
    # список слов голосования
    WORDS_OF_VOICES = ['ЗА','ПРОТИВ', 'ВОЗДЕРЖАЛСЯ']
    # Диапазон по у, в пределах которого слова голосования wordsOfVoices
    # считаются находящимися в одной строке
    LINE_PiXELS_RANGE = 10

    def __init__(self, base_file_name: str):
        self.base_bulletin: Bulletin = Bulletin()
        self.parse(base_file_name, dpi = 100)
        self.number = self.base_bulletin.get_bulletin_number().text.split(sep='-')[-1]
        self.base_path = os.path.dirname(base_file_name)+'/'+self.number
    
    def get_table_bbox(self,
                       tables_bboxes:[utl.BoundingBox],
                       y:float)->utl.BoundingBox:
        for tbox in tables_bboxes:
            if y > tbox.top and y < tbox.bottom:
                return tbox
        return None
    
    def parse(self, base_file_name: str, dpi: int=72):
        """Функция парсинга базового PDF-файла

        Args:
            base_file_name (str): Путь к файлу базового PDF
            dpi (int, optional): Разрешение, используемое для получения
            изображений страниц при конвертации PDF в картинку. Defaults to 72.
        """

        self.base_bulletin.file_name = base_file_name
        
        # Конвертим страницы pdf в список image
        imgs = convert_from_path(base_file_name, dpi)

        # Извлекаем bounding_boxes таблиц из страниц
        tables_bboxes = utl.get_bboxes_tables_page(pdf_path=base_file_name)
        
        # создаём объект файла PDF
        pdf_file = open(base_file_name, 'rb')

        # Используем pypdf для определения размеров страницы
        # и извлечения образцов картинок
        # создаём объект считывателя PDF
        pdf_readed = pypdf.PdfReader(pdf_file)
        pages = pdf_readed.pages

        for page_num, page in enumerate(pages):
            self.base_bulletin.pages.append(Page())
            self.base_bulletin.set_page_image(
                page_num=page_num, image=np.array(imgs[page_num]))
            #Определяем координаты углов страницы
            box = page.mediabox
            self.base_bulletin.set_page_bbox(
                page_num = page_num,
                bbox=utl.BoundingBox(
                left=box[0],
                top=box[1],
                right=box[2],
                bottom=box[3]))

        # Используем pdfminer.six для работы с объектами PDF
        # Задаем словарь для хранения предыдущего текста и его координаты y
        prev_text_data = {'text':'_', 'y':None}
        # Задаем переменную для хранения предыдущего id текста
        prev_line_id = None
        for page_num, page in enumerate(extract_pages(base_file_name)):
            # Находим все элементы, добавляем координату y1 и элемент
            page_elements = [(element.y1, element) for element in page._objs]
            # Сортируем все элементы по порядку нахождения на странице
            # Сортировка по убыванию, так как y=0 - нижний край страницы
            page_elements.sort(key=lambda a: a[0], reverse=True)
            # Определяем высоту страницы
            page_heigth = self.base_bulletin.pages[page_num].bbox.height
            # задаем множество для отсчета найденных слов WORDS_OF_VOICES
            # в одной полосе голосования
            found_words = set()
            # Перебираем элементы, составляющие страницу сверху вниз
            for component in page_elements:
                # Извлекаем элемент структуры страницы
                element = component[1]
                if element.y1>800 or element.y1<50\
                    and isinstance(element, LTFigure):
                    name = element.name
                    bbox = element.bbox
                    self.base_bulletin.pages[page_num].set_marker(
                        marker_name=name,
                        bbox=utl.BoundingBox(
                            left=bbox[0],
                            top=page_heigth-bbox[3],
                            right=bbox[2],
                            bottom=page_heigth-bbox[1]))
                if isinstance(element, LTTextContainer):
                    text = ''.join(c for c in element.get_text() if c.isprintable())
                    if element.y1>750 and ' №' in text:
                        texts = text.split(sep='№')
                        value = '' if len(texts)<2 else texts[1]
                        self.base_bulletin.set_bulletin_number(
                            value=value,
                            bbox=utl.BoundingBox(
                                left=element.x0,
                                top=page_heigth-element.y1,
                                right=element.x1,
                                bottom=page_heigth-element.y0))

                    # Не включаем тексты, координата y которых заведомо выходят
                    # за пределы размещения текстовых блоков с вопросами
                    elif element.y1>100:
                        try:
                            # Определяем индекс слова из списка слов голосования
                            index = self.WORDS_OF_VOICES.index(text)
                            # Определяем id строки с учетом координаты y в пределах +-line_pixels_range/2
                            line_id = int(element.y0/self.LINE_PiXELS_RANGE + 0.5)
                            if len(found_words) == 0 or line_id == prev_line_id:
                                # добавляем индекс найденного слова
                                found_words.add(index)
                            else:
                                found_words.clear() 
                            # Если найдены все слова из WORDS_OF_VOICES
                            if len(found_words) == len(self.WORDS_OF_VOICES):
                                found_words.clear() 
                                # находим bbox соответствующей таблицы
                                bbox = self.get_table_bbox(
                                    tables_bboxes=tables_bboxes['pages'][page_num]['tables'],
                                    y=page_heigth-element.y0)
                                self.base_bulletin.set_page_question_line(
                                    page_num=page_num,
                                    lineId=line_id,
                                    question_num=prev_text_data['text'],
                                    bbox=bbox)
                            prev_line_id = line_id
                        except ValueError:
                            # Сохраняем текст и координату y для последующих итераций (когда будет найдена строка голосования)
                            prev_text_data['text'] = '' if len(text.split())<1 else text.split()[0]
                            prev_text_data['y'] = element.y0
                            prev_line_id = None
                    elif element.y1<50 and '№' in text:
                        texts = text.split()
                        footer_page_number = '' if len(texts)<1 else texts[0]
                        footer_bulletin_number = '' if len(texts)<2 else texts[1].split('№')[1]
                        self.base_bulletin.set_page_footer(
                            page_num=page_num,
                            page_number=footer_page_number,
                            bulletin_number=footer_bulletin_number,
                            bbox=utl.BoundingBox(
                                left=element.x0,
                                top=page_heigth-element.y1,
                                right=element.x1,
                                bottom=page_heigth-element.y0))

    def get_data(self)->[[int,
                          utl.BoundingBox,
                          [TextBox],
                          [TextBox],
                          Footer
                          ]]:
        return self.base_bulletin.get_data()

    def save_data(self):
        utl.directory_clear(self.base_path)
        utl.text_to_file(path=self.base_path,
                              file_name='meeting.json',
                              text=self.toJSON())
        for i, page in enumerate(self.base_bulletin.pages):
            utl.save_image(path=self.base_path+os.sep+'base_PDF_pages',
                           file_name='page_'+str(i+1)+'.png',
                           image=page.image)

    def get_JSON(self):
        return{
            'meeting': self.number,
            'base_path': self.base_path,
            'base_bulletin': self.base_bulletin.get_JSON()
            }

    def toJSON(self):
        return json.dumps(self.get_JSON(), 
            sort_keys=False, indent=4, ensure_ascii=False)
