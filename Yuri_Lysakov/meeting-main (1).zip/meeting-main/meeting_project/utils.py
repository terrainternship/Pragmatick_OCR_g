import cv2
import cv2.typing as cvtp
import pdfplumber
import numpy as np
import os
import shutil
import pathlib


# Количество знаков после запятой для округления координат для print()
PRINT_ROUND_DIGITS_COUNT = 1
# Количество знаков после запятой для округления координат для JSON
SAVE_ROUND_DIGITS_COUNT = 4

class Point:
    """Точка с координатами
    """
    def __init__(self, x:float, y:float):
        """Функция инициализации объекта

        Args:
            x (float): Координата x
            y (float): Координата y
        """
        
        self.x: float = x
        self.y: float = y
        self.xi: int = int(round(x, 0))
        self.yi: int = int(round(y, 0))

#____________________________________________________________________
class BoundingBox:
    """Класс ограничивающего объект прямоугольника
    """
    def __init__(self,
                left: float = 0.0,
                top: float = 0.0,
                right: float = 0.0,
                bottom: float = 0.0):
        """Функция инициализации объекта

        Args:
            left (float, optional): левая координата x. Defaults to 0.0.
            top (float, optional): верхняя координата y. Defaults to 0.0.
            right (float, optional): правая координата x. Defaults to 0.0.
            bottom (float, optional): нижняя координата y. Defaults to 0.0.
        """
        self.left: float = left
        self.top: float = top
        self.right: float = right
        self.bottom: float = bottom
        self.height: float = self.bottom-self.top
        self.width: float = self.right-self.left
        self.centre: Point = Point((self.left+self.right/2),
                                (self.top+self.bottom/2))
    def __str__(self):
        """Функция вывода данных экземпляра класса для print()
        """

        return f' left: {round(self.left, PRINT_ROUND_DIGITS_COUNT)},'\
            f' top: {round(self.top, PRINT_ROUND_DIGITS_COUNT)},'\
            f' right: {round(self.right, PRINT_ROUND_DIGITS_COUNT)},'\
            f' bottom: {round(self.bottom, PRINT_ROUND_DIGITS_COUNT)},'\
            f' width: {round(self.width, PRINT_ROUND_DIGITS_COUNT)},'\
            f' height: {round(self.height, PRINT_ROUND_DIGITS_COUNT)}'

    def get_JSON(self):
        return {
            'left': round(self.left, SAVE_ROUND_DIGITS_COUNT),
            'top': round(self.top, SAVE_ROUND_DIGITS_COUNT),
            'right': round(self.right, SAVE_ROUND_DIGITS_COUNT),
            'bottom': round(self.bottom, SAVE_ROUND_DIGITS_COUNT)
            }

    def get_bbox_abs(self, d_x:float=0.0, d_y:float=0.0,
                     padding_x: float = 0.0, padding_y: float = 0.0):
        """Функция получения bbox в абсолютных координатах с паддингом и смещением

        Args:
            d_x (float, optional): Смещение по x. Defaults to 0.0.
            d_y (float, optional): Смещение по y. Defaults to 0.0.
            padding_x (float, optional): Padding по x в %. Defaults to 0.0.
            padding_y (float, optional): Padding по y в %. Defaults to 0.0.

        Returns:
            BoundingBox: 
        """

        pad_x = self.width*padding_x/100.0
        pad_y = self.height*padding_y/100.0
        left = self.left - d_x - pad_x
        top = self.top - d_y - pad_y
        right = self.right - d_x + pad_x
        bottom = self.bottom - d_y + pad_y
        return BoundingBox(left=left,
                           top=top,
                           right=right,
                           bottom=bottom)
    
    def get_bbox_norm(self, d_x:float=0.0, d_y:float=0.0,
                     padding_x: float = 0.0, padding_y: float = 0.0,
                     div_x: float = 1.0, div_y: float = 1.0):
        """Функция получения bbox в относительных координатах с паддингом и смещением

        Args:
            d_x (float, optional): Смещение по x. Defaults to 0.0.
            d_y (float, optional): Смещение по y. Defaults to 0.0.
            padding_x (float, optional): Padding по x в %. Defaults to 0.0.
            padding_y (float, optional): Padding по y в %. Defaults to 0.0.
            div_x (float, optional): Делитель по x. Defaults to 1.0.
            div_y (float, optional): Делитель по y. Defaults to 1.0.

        Returns:
            BoundingBox: 
        """
        bbox_abs=self.get_bbox_abs(d_x=d_x, d_y=d_y, padding_x=padding_x, padding_y=padding_y)
        left = bbox_abs.left/div_x
        top = bbox_abs.top/div_y
        right = bbox_abs.right/div_x
        bottom = bbox_abs.bottom/div_y
        return BoundingBox(left=left,
                           top=top,
                           right=right,
                           bottom=bottom)

#____________________________________________________________________
def cv2_show(title: str, image: cvtp.MatLike):
    """Процедура отображения изображения с помощью cv2

    Args:
        title (str, optional): Название изображения.
        img (numpy.ndarray): Данные изображения.
    """
    
    cv2.imshow(title, image) # Для компа
    # cv2_imshow(image)  # Для колаба
    cv2.waitKey(0)
    cv2.destroyAllWindows()

def bboxes_draw(title: str,
                image: cvtp.MatLike,
                norm_bboxes: [BoundingBox],
                is_relative: bool = True):
    """Отрисовка bboxes на изображении

    Args:
        title (str): Заголовок изображения
        image (cvtp.MatLike): Массив данных картинки
        bboxes (BoundingBox]): Список bbox-ов
    """

    for norm_bbox in norm_bboxes:
        width = image.shape[1] if is_relative else 1
        height = image.shape[0] if is_relative else 1
        left = norm_bbox.left*width
        top = norm_bbox.top*height
        right = norm_bbox.right*width
        bottom = norm_bbox.bottom*height
        cv2.rectangle(image,
                      (int(round(left, 0)), int(round(top, 0))),
                      (int(round(right, 0)), int(round(bottom, 0))),
                      (0, 255, 0),
                      1)
    cv2_show(title=title, image=image)

def crosses_draw(image_src: cvtp.MatLike,
                 points,
                 size: int = 5,
                 thickness: int = 1,
                 color: cvtp.Scalar = (0, 255, 0),
                 relative: bool = True
                 )->cvtp.MatLike:
    """Отрисовка перекрестий в заданных точках

    Args:
        image_src (cvtp.MatLike): Исходное изображение
        points (): Массив заданных точек
        size (int, optional): Длина луча перекрестия в пикселях. Defaults to 5.
        thickness (int, optional): Толщина линий перекрестий. Defaults to 1.
        color (cvtp.Scalar, optional): Цвет перекрестий. Defaults to (0, 255, 0).
        relative (bool, optional): Флаг относительности координат:
            True - относительные, False - абсолютные. Defaults to True.

    Returns:
        cvtp.MatLike: Результирующее изображение
    """

    result = image_src.copy()
    if len(points) == 0:
        return result
    if relative:
        # Приводим относительные координаты в абсолютные
        points = (points * image_src.shape[:2][::-1]).astype(np.int32)
    points = points.astype(np.int32)
    # Отмечаем центры квадратов
    for c in points:
        # cv2.circle(vis, tuple(c), radius, color, thickness)
        cv2.line(result, (c[0]-size, c[1]), (c[0]+size, c[1]), color, thickness=thickness)
        cv2.line(result, (c[0], c[1]-size), (c[0], c[1]+size), color, thickness=thickness)
    return result

def get_bboxes_tables_page(pdf_path: str):
    """Функция постраничного получения bounding_boxes таблиц PDF

    Args:
        pdf_path (str): полный путь к файлу.
    Returns:
        коллекция страниц с соответстующей для каждой страницы коллекцией таблиц
    """

    # Открываем файл pdf
    pdf = pdfplumber.open(pdf_path)
    # Определяем кол-во страниц
    num_pages = len(pdf.pages)

    num_pages = len(pdf.pages)

    # Словарь с bounding_boxes для всех страниц
    bboxes_pages = {'num_pages': num_pages,  # кол-во страниц
        'pages': {}  # страницы
        }
    # Цикл по страницам
    for page_num, page in enumerate(pdf.pages):
        # Находим координаты таблиц на текущей странице
        tables = page.find_tables()

        # Словарь с bounding_boxes для одной страницы
        bboxes_page = {'num_tables': len(tables),  # кол-во таблиц на странице
                    'tables': []  # таблицы
                    }
        # Извлекаем координаты таблиц для текущей страницы
        for table in tables:
            bbox = table.bbox
            bbox_norm = BoundingBox(
                left=bbox[0],
                top=bbox[1],
                right=bbox[2],
                bottom=bbox[3]
            )
            bboxes_page['tables'].append(bbox_norm)
        bboxes_pages['pages'][page_num] = bboxes_page
    return bboxes_pages

def directory_clear(path: str):
    """Очистка папки (удаление/создание)

    Args:
        path (str): путь к папке
    """
    # Удаляем папку folder, если она уже есть
    try:
        if os.path.isdir(path):
            shutil.rmtree(path)
    except Exception as e:
        print(f'Failed to delete {path}. Reason: {e}')

def save_image(path: str, file_name:str, image: cvtp.MatLike):
    """Сохранение изображения в файл

    Args:
        path (str): Путь сохранения
        file_name (str): Имя файла
        image (cvtp.MatLike): Данные изображения
    """
    p = pathlib.Path(path)
    p.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(path+os.sep+file_name, image)

def text_to_file(path: str, file_name: str, text: str):
    """Сохранение текста в файл

    Args:
        path (str): Путь
        file_name (str): Имя файла
        text : Сохраняемый текст
    """

    p = pathlib.Path(path)
    p.mkdir(parents=True, exist_ok=True)
    with open(path+os.sep+file_name, 'w') as file:
        file.write(text)