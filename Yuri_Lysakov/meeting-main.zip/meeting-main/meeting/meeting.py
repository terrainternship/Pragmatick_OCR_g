import pypdf
from pdfminer.high_level import extract_pages
from pdfminer.layout import LTTextContainer, LTFigure
from pdf2image import convert_from_path
from imutils.perspective import four_point_transform
import numpy as np
import functions as fn
import cv2

ROUND_DIGITS_COUNT = 2 # Количество знаков после запятой для округления

def m_round(x: float|int = 0)->float:
    """Функция округления до заданного количества знаков

    Args:
        x (float | int, optional): округляемое значение. Defaults to 0.

    Returns:
        float: округленное значение
    """
    return round(x, ROUND_DIGITS_COUNT)

class Point:
    'Точка с координатами'
    def __init__(self, x:float, y:float):
        self.x: float = m_round(x)
        self.y: float = m_round(y)

class BoundingBox:
    """Класс ограничивающего объект прямоугольника
    """
    def __init__(self,
                left: float = 0.0,
                top: float = 0.0,
                right: float = 0.0,
                bottom: float = 0.0
                ):
        """Функция инициализации объекта

        Args:
            l (float, optional): левая координата. Defaults to 0.0.
            t (float, optional): верхняя координата. Defaults to 0.0.
            r (float, optional): правая координата. Defaults to 0.0.
            b (float, optional): нижняя координата. Defaults to 0.0.
        """
        self.left: float = m_round(left)
        self.top: float = m_round(top)
        self.right: float = m_round(right)
        self.bottom: float = m_round(bottom)
        self.height: float = self.bottom-self.top
        self.width: float = self.right-self.left
        self.center: Point = Point((self.top+self.bottom/2),
                                (self.left+self.right/2))
    def __str__(self):
        return f' left: {self.left}, top: {self.top}, right: {self.right}, bottom: {self.bottom}'

#____________________________________________________________________
class Marker:
    'Маркер'
    def __init__(self, name: str, bbox: BoundingBox):
        self.name: str = name
        self.bbox: BoundingBox = bbox

#____________________________________________________________________
class QuestionLine:
    'Полоса данных по вопросу'
    def __init__(self, question: str, bbox: BoundingBox):
        self.question: str = question # Номер вопроса
        self.bbox: BoundingBox = bbox # BoundingBox

#____________________________________________________________________
class BulletinNumber:
    'Номер голосования'
    def __init__(self, value: str, bbox: BoundingBox):
        self.value: str = value
        self.bbox: BoundingBox = bbox # BoundingBox

#____________________________________________________________________
class Footer:
    'Нижний колонтитул'
    def __init__(self, page_number: str, bulletinNumber: str, bbox: BoundingBox):
        self.page_number: str = page_number
        self.bulletinNumber: str = bulletinNumber
        self.bbox: BoundingBox = bbox # BoundingBox

#____________________________________________________________________
class Page:
    'Страница'
    def __init__(self):
        self.bbox: BoundingBox # BoundingBox
        self.images = {} # набор изображений на странице
        self.__lineIdDict: dict[int, int] = {} # Словарь id номеров строк голосования lineId:number
        self.questionLines: dict[int, QuestionLine] = {}
        self.footer: Footer
        self.markers: dict[int, Marker] = {}
        self.page_pixel_image: np.ndarray # пиксельное изображение страницы

    def set_bbox(self, bbox: BoundingBox):
        self.bbox = bbox

    def setImages(self, imageName: str, image):
        self.images[imageName] = image
        
    def set_page_pixel_image(self, pxl_image: np.ndarray):
        self.page_pixel_image = pxl_image

    def setQuestion(self, lineId: int, question: str, bbox: BoundingBox):
        if lineId not in self.__lineIdDict:
            self.__lineIdDict[lineId] = len(self.__lineIdDict)
            self.questionLines[self.__lineIdDict[lineId]] = QuestionLine(
                question=question,
                bbox=bbox)

    def setFooter(self, page_number: str, bulletinNumber: str, bbox: BoundingBox):
        self.footer = Footer(page_number=page_number,
                            bulletinNumber=bulletinNumber,
                            bbox=bbox)

    def setMarker(self, markerName: str, bbox: BoundingBox):
        self.markers[len(self.markers)] = Marker(markerName, bbox=bbox)

    def getImages(self):
        result = []
        for key, img in self.images.items():
            result.append([key, img])
        return result

    def getQuestionLines(self):
        # result = []
        # for key, questionLine in self.questionLines.items():
        #     result.append([questionLine.question, questionLine.bbox])
        return self.questionLines.values()

    def getMarkers(self):
        result = []
        for key, marker in self.markers.items():
            img=None
            for ikey, image in self.images.items():
                if marker.name == ikey.rsplit(".", 1)[0]:
                    img=image
                    break
            result.append([key, marker, img])
        return result
#____________________________________________________________________
class Bulletin:
    'Бюллетень голосования'
    def __init__(self):
        self.fileName: str
        self.bulletinNumber: BulletinNumber
        self.pages: list[Page] = []

    def setBulletinNumber(self, value: str, bbox: BoundingBox):
        self.bulletinNumber = BulletinNumber(value=value, bbox=bbox)

    def set_page_bbox(self, page_num: int, bbox: BoundingBox):
        self.pages[page_num].set_bbox(bbox=bbox)

    def setPageImage(self, page_num: int, imageName: str, image):
        self.pages[page_num].setImages(imageName, image)

    def set_page_pixel_image(self, page_num: int, pxl_image: np.ndarray):
        self.pages[page_num].page_pixel_image = pxl_image

    def setPageQuestion(self, page_num: int, lineId: int,
                        question:str, bbox: BoundingBox):
        self.pages[page_num].setQuestion(lineId=lineId, question=question,
                                        bbox = bbox)

    def setPageFooter(self, page_num: int, page_number: str, bulletinNumber: str,
                    bbox: BoundingBox):
        self.pages[page_num].setFooter(page_number, bulletinNumber, bbox = bbox)

    def getBullotNumber(self):
        return self.bulletinNumber

    def getData(self):
        result = []
        for page_num, page in enumerate(self.pages):
            result.append([page_num, page.bbox, page.getImages(),
                        page.getMarkers(), page.getQuestionLines(),
                        page.footer])
        return result

    def draw_bboxes(self):
        """Отрисовываем все bboxes на изображениях страниц
        """
        #bboxes.append(se)
        for page_num, page in enumerate(self.pages):
            img = page.page_pixel_image
            bboxes = list()
            if page_num==0:
                fn.cv2_show(img, "Image")
                bboxes.append(self.bulletinNumber.bbox)
            for marker in page.markers.values():
                bboxes.append(marker.bbox)
            for question_line in page.questionLines.values():
                bboxes.append(question_line.bbox)
            bboxes.append(page.footer.bbox)
            # Цикл по рамкам
            for bbox in bboxes:
                left = bbox.left# * width
                top = bbox.top# * height
                right = bbox.right# * width
                bottom = bbox.bottom# * height
                cv2.rectangle(img,
                            (int(left), int(top)),
                            (int(right), int(bottom)),
                            (0, 255, 0),2)
            fn.cv2_show(img, "Image")
#____________________________________________________________________
class Meeting:
    """Класс Голосования
    """
    # список слов голосования
    WORDS_OF_VOICES = ['ЗА','ПРОТИВ', 'ВОЗДЕРЖАЛСЯ']
    # Диапазон по у, в пределах которого слова голосования wordsOfVoices
    # считаются находящимися в одной строке
    LINE_PiXELS_RANGE = 10

    def __init__(self, baseFileName: str):
        self.baseBulletin: Bulletin = Bulletin()
        self.parse(baseFileName, skip_num_tables=4, padding=1.0, dpi = 72)

    def getData(self):
        return self.baseBulletin.getData()
    
    def get_table_bbox(self, tables_bboxes, y:float)->BoundingBox:
        for tbox in tables_bboxes:
            if y > tbox['top'] and y < tbox['bottom']:
                return BoundingBox(
                    left=tbox['left'],
                    top=tbox['top'],
                    right=tbox['right'],
                    bottom=tbox['bottom'])
        return None
    
    def parse(self, baseFileName: str, skip_num_tables: int = 0,
            padding: float | int = 0, dpi: int =72):
        """
        Извлекает из PDF-файла координаты bboxes элементов всех страниц файла. 
        :param baseFileName: путь к файлу базового PDF
        :param skip_num_tables: кол-во таблиц на первой странице, которые не будут включены в найденные bboxes
        :param padding: Отступ сверху, снизу и слева, справа от границы таблицы в % от ширины и высоты страницы
        :param dpi: кол-во точек на дюйм в полученном изображении при конвертации PDF в PNG
            dpi=72 - значение по умолчанию, соответствует координатному пространству объектной модели pdf.
        """
        self.baseBulletin.fileName = baseFileName
        
        # Конвертим страницы pdf в список image
        imgs = convert_from_path(baseFileName, dpi)

        # Извлекаем bounding_boxes таблиц из страниц
        tables_bboxes = fn.get_bboxes_tables_page(
            baseFileName, skip_num_tables,
            float(padding))
        
        # создаём объект файла PDF
        pdfFile = open(baseFileName, 'rb')

        # Используем pypdf для определения размеров страницы и извлечения образцов картинок
        # создаём объект считывателя PDF
        pdfReaded = pypdf.PdfReader(pdfFile)
        pages = pdfReaded.pages

        for page_num, page in enumerate(pages):
            self.baseBulletin.pages.append(Page())
            self.baseBulletin.set_page_pixel_image(
                page_num=page_num, pxl_image=np.array(imgs[page_num]))
            #Определяем координаты углов страницы
            box = page.mediabox
            self.baseBulletin.set_page_bbox(
                page_num = page_num,
                bbox=BoundingBox(
                left=box[0],
                top=box[1],
                right=box[2],
                bottom=box[3]))
            # Определяем имеющиеся на странице картинки
            # если на странице может быть несколько разных картинок
            # с одинаковым именем (не уверен), то будет только последняя
            for i, img in enumerate(page.images):
                self.baseBulletin.setPageImage(
                    page_num=page_num,
                    imageName = img.name,
                    image=img.image)

        # Используем pdfminer.six для работы с объектами PDF
        # Задаем словарь для хранения предыдущего текста и его координаты y
        prevTextData = {'text':'_', 'y':None}
        # Задаем переменную для хранения предыдущего id текста
        prev_line_id = None
        for page_num, page in enumerate(extract_pages(baseFileName)):
            # Находим все элементы, добавляем координату y1 и элемент
            pageElements = [(element.y1, element) for element in page._objs]
            # Сортируем все элементы по порядку нахождения на странице
            # Сортировка по убыванию, так как y=0 - нижний край страницы
            pageElements.sort(key=lambda a: a[0], reverse=True)
            # Определяем высоту страницы
            pageHeigth = self.baseBulletin.pages[page_num].bbox.height
            # задаем множество для отсчета найденных слов WORDS_OF_VOICES
            # в одной полосе голосования
            found_words = set()
            # Перебираем элементы, составляющие страницу сверху вниз
            for i, component in enumerate(pageElements):
                # Извлекаем элемент структуры страницы
                element = component[1]
                if element.y1>800 or element.y1<50\
                    and isinstance(element, LTFigure):
                    name = element.name
                    pageImages = self.baseBulletin.pages[page_num].getImages()
                    for j, image_data in enumerate(pageImages):
                        if name == image_data[0].rsplit(".", 1)[0]:
                            box = element.bbox
                            self.baseBulletin.pages[page_num].setMarker(
                                markerName=name,
                                bbox=BoundingBox(
                                    left=box[0],
                                    top=pageHeigth-box[3],
                                    right=box[2],
                                    bottom=pageHeigth-box[1]))
                            break
                    #print(element.name, element.bbox) [image_left, image_top, image_right, image_bottom] = [element.x0,element.y0,element.x1,element.y1]
                if isinstance(element, LTTextContainer):
                    text = ''.join(c for c in element.get_text() if c.isprintable())
                    if element.y1>750 and ' №' in text:
                        texts = text.split(sep='№')
                        value = '' if len(texts)<2 else texts[1]
                        self.baseBulletin.setBulletinNumber(
                            value=value,
                            bbox=BoundingBox(
                                left=element.x0,
                                top=pageHeigth-element.y1,
                                right=element.x1,
                                bottom=pageHeigth-element.y0))

                    # Не включаем тексты, координата y которых заведомо выходят
                    # за пределы размещения текстовых блоков с вопросами
                    elif element.y1>100:
                        try:
                            # Определяем индекс слова из списка слов голосования
                            index = self.WORDS_OF_VOICES.index(text)
                            # Определяем id строки с учетом координаты y в пределах +-line_pixels_range/2
                            line_id = int(element.y0/self.LINE_PiXELS_RANGE + 0.5)
                            if len(found_words) == 0 or line_id == prev_line_id:
                                # добавляем индекс найденного слова
                                found_words.add(index)
                            else:
                                found_words.clear() 
                            # Если найдены все слова из WORDS_OF_VOICES
                            if len(found_words) == len(self.WORDS_OF_VOICES):
                                found_words.clear() 
                                # находим bbox соответствующей таблицы
                                bbox = self.get_table_bbox(
                                    tables_bboxes=tables_bboxes['pages'][page_num]['tables'],
                                    y=pageHeigth-element.y0)
                                self.baseBulletin.setPageQuestion(
                                    page_num=page_num,
                                    lineId=line_id,
                                    question=prevTextData['text'],
                                    bbox=bbox)
                            prev_line_id = line_id
                        except ValueError:
                            # Сохраняем текст и координату y для последующих итераций (когда будет найдена строка голосования)
                            prevTextData['text'] = '' if len(text.split())<1 else text.split()[0]
                            prevTextData['y'] = element.y0
                            prev_line_id = None
                    elif element.y1<50 and '№' in text:
                        texts = text.split()
                        footerpage_number = '' if len(texts)<1 else texts[0]
                        footerBulletinNumber = '' if len(texts)<2 else texts[1].split('№')[1]
                        self.baseBulletin.setPageFooter(
                            page_num=page_num,
                            page_number=footerpage_number,
                            bulletinNumber=footerBulletinNumber,
                            bbox=BoundingBox(
                                left=element.x0,
                                top=pageHeigth-element.y1,
                                right=element.x1,
                                bottom=pageHeigth-element.y0))