import cv2
import pdfplumber
import numpy as np

def cv2_show(img: np.ndarray, name: str ='Image'):
    """Процедура отображения изображения с помощью cv2

    Args:
        img (numpy.ndarray): изображение
        
        name (str, optional): Имя изображения. Defaults to 'Image'.
    """
    
    cv2.imshow(name, img) # Для компа
    # cv2_imshow(img)  # Для колаба
    cv2.waitKey(0)
    cv2.destroyAllWindows()

def get_bboxes_tables_page(pdf_path: str, skip_num_tables: int=0,
                            padding: float = 1.0):
    """Функция постраничного получения bounding_boxes таблиц PDF

    Args:
        pdf_path (str): полный путь к файлу.
        
        skip_num_tables (int, optional): кол-во таблиц на первой странице,
        которые не будут включены в найденные bboxes.Defaults to 0
        
        padding (float, optional): Отступ слева, сверху, справа, снизу
        от границы таблицы в % от ширины таблицы. Defaults to 1.0

    Returns:
        коллекция страниц с соответстующей для каждой страницы коллецией таблиц
    """

    # Открываем файл pdf
    pdf = pdfplumber.open(pdf_path)
    # Определяем кол-во страниц
    num_pages = len(pdf.pages)
    # print('Кол-во страниц в PDF: ', num_pages, ' | Файл: ', pdf_path)

    num_pages = len(pdf.pages)

    # Словарь с bounding_boxes для всех страниц
    bboxes_pages = {'num_pages': num_pages,  # кол-во страниц
        'pages': {}  # страницы
        }
    # Цикл по страницам
    for page_num, page in enumerate(pdf.pages):
        # Находим координаты таблиц на текущей странице
        tables = page.find_tables()

        # Удаляем первые 4 таблицы у первого листа
        if page_num == 0 and len(tables) > 3:
            tables = tables[skip_num_tables:]
        print('Кол-во таблиц на странице ', page_num+1, ' : ', len(tables), ' шт')

        # Словарь с bounding_boxes для одной страницы
        bboxes_page = {'num_tables': len(tables),  # кол-во таблиц на странице
                    'tables': []  # таблицы
                    }
        # Извлекаем координаты таблиц для текущей страницы
        for table_num, table in enumerate(tables):
            bbox = table.bbox
            pad = (bbox[2]-bbox[0])*padding/100.0
            left = bbox[0] - pad
            top = bbox[1] - pad
            right = bbox[2] + pad
            bottom = bbox[3] + pad
            # if left < 0.0:
            #     left = 0.0
            # if top < 0.0:
            #     top = 0.0
            # if right > 1.0:
            #     right = 1.0
            # if bottom > 1.0:
            #     bottom = 1.0
            bbox_norm = {'left': left,
                        'top': top,
                        'right': right,
                        'bottom': bottom}
            bboxes_page['tables'].append(bbox_norm)
        bboxes_pages['pages'][page_num] = bboxes_page
    return bboxes_pages

