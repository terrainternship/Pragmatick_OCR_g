import meeting as mtg

meeting = mtg.Meeting('./bulletins/testPDF.pdf')
print(f'Имя базового PDF-файла: "{meeting.baseBulletin.fileName}"')
bulletin_number = meeting.baseBulletin.getBullotNumber()
print(f'Бюллетень № {bulletin_number.value}, bbox:{bulletin_number.bbox}')
meeting_data = meeting.getData()
for page_num, page_bbox, page_images, page_markers_data, page_question_lines,\
    footer in meeting_data:
    print(f'  Страница №{page_num +1}, bbox:{page_bbox}')
    for i, page_marker_data in enumerate(page_markers_data):
        marker = page_marker_data[1]
        print(f'      Маркер №{i+1}: name:{marker.name}, bbox:{marker.bbox}')
    for i, page_question_line in enumerate(page_question_lines):
        print(f'      Вопрос {i+1}: №{page_question_line.question}, bbox:{page_question_line.bbox}')
    print(f'    Нижний колонтитул: номер страницы: {footer.page_number}, бюллетень № {footer.bulletinNumber}, bbox:{footer.bbox}')

meeting.baseBulletin.draw_bboxes()