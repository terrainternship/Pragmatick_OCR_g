Стажировка Университет ИИ (01.11.2023-31.01.2024)
Проект распознавания бюллетеней голосования (ЖКХ)
https://github.com/terrainternship/Pragmatick_OCR_g

Установка библиотек:
sudo apt install xpdf
python3 -m pip install pdfplumber
python3 -m pip install pdf2image
python3 -m pip install numpy
python3 -m pip install pdfminer.six
python3 -m pip install pypdf
python3 -m pip install pillow
python3 -m pip install matplotlib
python3 -m pip install opencv-python
python3 -m pip install imutils
python3 -m pip install scipy

Использованы функции парсинга таблиц PDF,
    отрисовки bounding box от GrigorukAlex (functions.py, meeting.py)

Запускать main.py